// BISHES XP — lightweight site interactions.
// Replace this value with your preferred public contact email before launch.
const CONTACT_EMAIL = "ADD_YOUR_EMAIL_HERE";

document.addEventListener("DOMContentLoaded", () => {
  const year = document.querySelector("[data-year]");
  if (year) year.textContent = new Date().getFullYear();
  const toggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".main-nav");
  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      const open = toggle.getAttribute("aria-expanded") === "true";
      toggle.setAttribute("aria-expanded", String(!open));
      toggle.setAttribute("aria-label", open ? "Open navigation" : "Close navigation");
      nav.classList.toggle("open", !open);
    });
    nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
      nav.classList.remove("open"); toggle.setAttribute("aria-expanded", "false"); toggle.setAttribute("aria-label", "Open navigation");
    }));
  }
  const form = document.querySelector("#contact-form");
  const status = document.querySelector("#form-status");
  if (form && status) form.addEventListener("submit", event => {
    event.preventDefault(); if (!form.reportValidity()) return;
    if (!CONTACT_EMAIL || CONTACT_EMAIL === "ADD_YOUR_EMAIL_HERE") {
      status.textContent = "The form is ready, but it cannot send yet. Add your contact email in assets/js/main.js, then publish the change."; return;
    }
    const data = new FormData(form);
    const subject = encodeURIComponent("BISHES XP website — " + data.get("topic"));
    const body = encodeURIComponent("Name: " + data.get("name") + "\nEmail: " + data.get("email") + "\nTopic: " + data.get("topic") + "\n\n" + data.get("message"));
    window.location.href = "mailto:" + CONTACT_EMAIL + "?subject=" + subject + "&body=" + body;
    status.textContent = "Your email app should open with the message prepared. Send it there to complete delivery.";
  });
});

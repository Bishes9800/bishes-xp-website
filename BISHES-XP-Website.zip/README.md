# BISHES XP — Official Website

A responsive multi-page website for the BISHES XP independent gaming brand.

**Tagline:** LEVEL UP. PLAY DIFFERENT.

## Pages
- Home — brand introduction and featured game
- Games — Arrowzle: Escape the Grid and upcoming releases
- About — brand story and values
- Contact — contact form preview with a mail-app handoff

## Publish with GitHub Pages
1. Open this repository on GitHub.
2. Select **Settings** → **Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select branch **main** and folder **/(root)**.
5. Select **Save**. GitHub Pages will publish the site after its build completes.

Expected address: https://bishes9800.github.io/bishes-xp-website/

## Before launch
- Open `assets/js/main.js` and replace `ADD_YOUR_EMAIL_HERE` with the public email address that should receive enquiries. The contact form uses the visitor's default email app; it does not send messages through a server.
- Store and download links are not active because no official listing URLs have been supplied yet.
- Review the Arrowzle link in `index.html` and `games.html` if its address changes.

## Edit the site
Pages are plain HTML. Shared styles are in `assets/css/styles.css`; navigation and contact behaviour are in `assets/js/main.js`. No build tools or package installation are required.
